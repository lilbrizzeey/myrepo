# Facilities
Access to All reviews Related Things - List of Scopes to be used in Authorization<br>
    Facilities.read,<br>
    Facilities.create,<br>
    Facilities.delete, <br>
    Facilities.update<br>

The facilities API shows the facilities a hotel has like restaurant, as well as images of the faciilty, the API could also get bank details of a specific hotel like bank, name account name and account number.<br>
Only the admin can access the bank details of this API. The scopes available are read, create, delete and update.
## Show facilities for a hotel


> Example request:

```php
<?php
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://api.hotels.ng/internal/hotels/{hotel_id}/facilities?access_token=");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  "Content-Type: application/xml",
  "Accept: application/json"
));

$response = curl_exec($ch);
curl_close($ch);

var_dump($response);Response
```

> Example response:

```json
[
  {

    "status": "success",
    "message": "Object facilities",
    "data": {
      "id": 1967,
      "object_id": 25449,
      "facility_type_id": 100,
      "facility_type_count": null,
      "object_type": "hotel",
      "created_at": {},
      "updated_at": null,
      "facility_name": "Restaurant",
      "img_url": "restaurant.png"
    }

  }

]
```

This endpoint shows the facilities available for a specific hotel.

### HTTP Request

`GET https://api.hotels.ng/internal/hotels/hotel_id/facilities?access_token=`

### URL Parameters

Parameter | Type | Description
--------- | ------- | -----------
hotel_id | Number | id of the Hotel
access_token | String | Your access token

###Response Body

Attribute | Type | Description
--------- | ------- | -----------
        id| integer | Customer user-supplied webhook identifier.
object_id | integer | Id of the object supplied
facility_type_id| integer| Id of the facility
  object_type| string |type of object supplied
 facility_name| string | name of facility supplied
img_url | string | link to the image of facility




## Show bank details for a hotel

> Example request:

```php
<?php
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://api.hotels.ng/internal/hng/bank_details/{hotel_id}?access_token=");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  "Content-Type: application/json",
  "Accept: application/json"
));

$response = curl_exec($ch);
curl_close($ch);

var_dump($response);
```


> Example response:

```json
[
  {
    "status": "success",
    "data": {
      "id": 406,
      "property_id": 49583,
      "account_name": "Avalon Intercontinental nigeria LTD",
      "account_number": "035274049",
      "bank_name": "FCMB",
      "sort_code": null
    }

  }
]
```

This endpoint shows the banks details of a specific hotel.

### HTTP Request

`GET https://api.hotels.ng/internal/hng/bank_details/hotel_id?access_token=`

### URL Parameters
Parameter | Type | Description
--------- | ------- | -----------
hotel_id | Number | id of the Hotel
access_token | String | Your access token

###Response Body

Attribute | Type | Description
--------- | ------- | -----------
        id| integer | Customer user-supplied webhook identifier.
property_id| integer | Id of the property
account_name| string| name of account holder
account_number| integer |number peculiar to the account
bank_name| string | name of the bank
